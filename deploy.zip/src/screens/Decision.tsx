import { useEffect, useRef } from "react";
import type { Analysis } from "../types";
import { t } from "../i18n";
import { getDecisionSummary } from "../decision";
import { lawCheckScope } from "../lawcheck";
import { getOfficialLawUrl } from "../contract";
import { Severity } from "../components/Severity";

// A personalized decision-preparation brief: clear commitments, consequential
// review items, answerable comprehension prompts, and genuine open questions.
// It deliberately avoids a verdict, safety score, or recommendation to sign.
export function Decision({
  analysis,
  onOpenClause,
  onOriginal,
  onDownload,
  dlMsg,
}: {
  analysis: Analysis;
  onOpenClause: (id: string) => void;
  onOriginal: () => void;
  onDownload: () => void;
  dlMsg: string;
}) {
  const s = t(analysis.lang);
  const brief = getDecisionSummary(analysis);
  const headingRef = useRef<HTMLHeadingElement>(null);
  const hasClause = (id: string | undefined) => !!id && analysis.clauses.some((clause) => clause.id === id);
  const clauseLevel = (id: string) => analysis.clauses.find((clause) => clause.id === id)?.level;

  // The sections are steps in a walkthrough, not severity levels — numbering them
  // leaves the level marks (! △ ✓) meaning exactly one thing each, on the clauses
  // themselves. The clarify panel only appears when the contract leaves something
  // open, so the numbers are computed rather than written down.
  const hasClarify = brief.clarificationQuestions.length > 0;
  const law = lawCheckScope(analysis);
  let n = 0;
  const step = {
    agree: ++n,
    review: ++n,
    clarify: hasClarify ? ++n : 0,
    law: law.checked > 0 ? ++n : 0,
    understand: ++n,
  };

  useEffect(() => {
    headingRef.current?.focus();
  }, []);

  return (
    <section className="screen shell decision-screen" aria-labelledby="de-h">
      <header className="decision-hero">
        <div className="decision-kicker">
          {s.decisionBriefLabel} <span aria-hidden="true">·</span> {analysis.contractType}
        </div>
        <h1 className="decision-title" id="de-h" ref={headingRef} tabIndex={-1}>
          {s.decisionTitle}
        </h1>
        <p className="decision-lead">{s.decisionSub}</p>
        <p className="decision-source-hint">{s.decisionSourceHint}</p>
      </header>

      <section className="decision-section" aria-labelledby="agree-h">
        <div className="decision-section-head">
          <span className="decision-step" aria-hidden="true">
            {step.agree}
          </span>
          <div>
            <h2 id="agree-h">{s.decisionAgreeHeading}</h2>
            <p>{s.decisionAgreeSub}</p>
          </div>
        </div>

        {brief.commitments.length > 0 ? (
          <ul className="commitment-grid">
            {brief.commitments.map((commitment) => (
              <li className="commitment-card" key={`${commitment.clauseId}:${commitment.title}`}>
                {commitment.value && <div className="commitment-value">{commitment.value}</div>}
                <h3>{commitment.title}</h3>
                <p>{commitment.explanation}</p>
                <button className="link-btn" onClick={() => onOpenClause(commitment.clauseId)}>
                  {s.showClause} <span aria-hidden="true">→</span>
                </button>
              </li>
            ))}
          </ul>
        ) : (
          <div className="brief-empty">
            <p>{s.missingInfo}</p>
          </div>
        )}
      </section>

      <div className={`decision-attention-grid${brief.clarificationQuestions.length === 0 ? " single" : ""}`}>
        <section className="decision-panel review-panel" aria-labelledby="review-h">
          <div className="decision-panel-head">
            <span className="decision-step" aria-hidden="true">
              {step.review}
            </span>
            <div>
              <h2 id="review-h">{s.decisionReviewHeading}</h2>
              <p>{s.decisionReviewSub}</p>
            </div>
          </div>

          {brief.reviewItems.length > 0 ? (
            <ul className="review-list">
              {brief.reviewItems.map((item) => (
                <li className="review-card" key={item.clauseId}>
                  {clauseLevel(item.clauseId) && <Severity level={clauseLevel(item.clauseId)!} lang={analysis.lang} />}
                  <h3>{item.title}</h3>
                  <p>{item.explanation}</p>
                  <p className="review-reason">
                    <strong>{s.whyLookAgain}</strong> {item.reason}
                  </p>
                  <button className="link-btn" onClick={() => onOpenClause(item.clauseId)}>
                    {s.reviewClause} <span aria-hidden="true">→</span>
                  </button>
                </li>
              ))}
            </ul>
          ) : (
            <div className="brief-empty compact">
              <span className="state-badge clear">
                <span aria-hidden="true">✓</span> {s.reviewEmptyTitle}
              </span>
              <p>{s.reviewEmptyBody}</p>
            </div>
          )}
        </section>

        {brief.clarificationQuestions.length > 0 && (
          <section className="decision-panel clarify-panel" aria-labelledby="clarify-h">
            <div className="decision-panel-head">
              <span className="decision-step" aria-hidden="true">
                {step.clarify}
              </span>
              <div>
                <h2 id="clarify-h">{s.decisionClarifyHeading}</h2>
                <p>{s.decisionClarifySub}</p>
              </div>
            </div>
            <ul className="clarification-list">
              {brief.clarificationQuestions.map((item) => (
                <li className="clarification-card" key={`${item.clauseId ?? "open"}:${item.question}`}>
                  <h3>{item.question}</h3>
                  {item.reason && <p>{item.reason}</p>}
                  {hasClause(item.clauseId) && (
                    <button className="link-btn" onClick={() => onOpenClause(item.clauseId!)}>
                      {s.showClause} <span aria-hidden="true">→</span>
                    </button>
                  )}
                </li>
              ))}
            </ul>
          </section>
        )}
      </div>


      {law.checked > 0 && (
        <section className="decision-section law-section" aria-labelledby="law-h">
          <div className="decision-section-head">
            <span className="decision-step" aria-hidden="true">
              {step.law}
            </span>
            <div>
              <h2 id="law-h">{s.lawHeading}</h2>
              <p>{s.lawSub}</p>
            </div>
          </div>

          {law.hits.length > 0 ? (
            <ul className="law-list">
              {law.hits.map((hit) => {
                const url = getOfficialLawUrl(hit.law, hit.section);
                return (
                  <li className="law-card" key={hit.id}>
                    <div className="law-cite">
                      {url ? (
                        <a href={url} target="_blank" rel="noopener noreferrer">
                          {hit.cite}
                          <span className="law-cite-cta">{s.viewOfficialLaw}</span>
                        </a>
                      ) : (
                        hit.cite
                      )}
                    </div>
                    <div className="law-row">
                      <div className="law-col-label">{s.lawRuleLabel}</div>
                      <p>{hit.rule}</p>
                    </div>
                    <div className="law-row law-row-contract">
                      <div className="law-col-label">{s.lawContractLabel}</div>
                      <p>{hit.contract}</p>
                    </div>
                    <button className="link-btn" onClick={() => onOpenClause(hit.clauseId)}>
                      {s.showClause} <span aria-hidden="true">→</span>
                    </button>
                  </li>
                );
              })}
            </ul>
          ) : (
            <div className="brief-empty compact">
              <span className="state-badge clear">
                <span aria-hidden="true">✓</span> {s.lawEmptyTitle}
              </span>
              <p>{s.lawEmptyBody(law.checked)}</p>
            </div>
          )}

          <p className="law-scope">{s.lawScope(law.checked)}</p>
          <p className="legal-note law-limit">{s.lawLimit}</p>
        </section>
      )}
      {brief.understandingQuestions.length > 0 && (
        <section className="decision-section understanding-section" aria-labelledby="understand-h">
          <div className="decision-section-head">
            <span className="decision-step" aria-hidden="true">
              {step.understand}
            </span>
            <div>
              <h2 id="understand-h">{s.decisionUnderstandHeading}</h2>
              <p>{s.decisionUnderstandSub}</p>
            </div>
          </div>
          <div className="understanding-list">
            {brief.understandingQuestions.map((item, index) => (
              <details className="understanding-item" key={`${item.clauseId}:${item.question}`}>
                <summary>
                  <span className="question-number" aria-hidden="true">
                    {index + 1}
                  </span>
                  <span>{item.question}</span>
                  <span className="details-chevron" aria-hidden="true">
                    ⌄
                  </span>
                </summary>
                <div className="understanding-answer">
                  <div className="answer-label">{s.decisionAnswerLabel}</div>
                  <p>{item.answer}</p>
                  <button className="link-btn" onClick={() => onOpenClause(item.clauseId)}>
                    {s.showClause} <span aria-hidden="true">→</span>
                  </button>
                </div>
              </details>
            ))}
          </div>
        </section>
      )}

      <div className="overview-foot decision-actions">
        <button className="btn" onClick={onOriginal}>
          {s.viewOriginal}
        </button>
        <button className="btn btn-primary" onClick={onDownload}>
          {s.downloadSummary}
        </button>
      </div>
      {dlMsg && (
        <div className="print-status" role="status" aria-live="polite">
          {dlMsg}
        </div>
      )}

      <p className="disclaimer decision-disclaimer">{s.disclaimerLong}</p>
    </section>
  );
}
